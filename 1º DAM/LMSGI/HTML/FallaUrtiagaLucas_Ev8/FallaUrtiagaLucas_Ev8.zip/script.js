//EJERCICIO 1:

function redondearArrays(unArray){
    for(let i=0; i<unArray.length; i++){
        if(unArray[i]<0 || isNaN(unArray[i])){
            unArray.splice(indexOf(unArray[i]),1);
        }else{
            Math.round(unArray[i]);
        }
    }
}

redondearArrays(unArray);

//EJERCICIO 2:

function eliminarExtremos(unArray){
    unArray.sort(function comparar (a, b){
        return b-a;
    })

    unArray.shift();

    unArray.pop();
}

eliminarExtremos(unArray);

//EJERCICIO 3:

function parsearNotas(str){

    let filtro = str.split('#');
}

parsearNotas(str);

//EJERCICIO 4:

function principal(){

    function calcularMedia(eliminarExtremos(redondearArrays(parsearNotas(str)))){

    }

    for(let i=0; i<unArray.length; i++){
        suma += Number(unArray[i]);  
    }


 
    let media = unArray

    alert()
}

principal();